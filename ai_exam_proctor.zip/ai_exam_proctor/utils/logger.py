"""
Event Logger — writes cheating events to a rotating daily log file.
"""

import os
import time
import logging
from logging.handlers import TimedRotatingFileHandler

_LOG_DIR = os.path.join(os.path.dirname(__file__), "..", "logs")


class EventLogger:
    def __init__(self):
        os.makedirs(_LOG_DIR, exist_ok=True)
        log_path = os.path.join(_LOG_DIR, "events.log")

        self._logger = logging.getLogger("exam_proctor")
        self._logger.setLevel(logging.DEBUG)

        if not self._logger.handlers:
            handler = TimedRotatingFileHandler(
                log_path, when="midnight", backupCount=7, encoding="utf-8"
            )
            fmt = logging.Formatter("%(asctime)s | %(levelname)-8s | %(message)s",
                                    datefmt="%Y-%m-%d %H:%M:%S")
            handler.setFormatter(fmt)
            self._logger.addHandler(handler)

    def log(self, message: str, severity: str = "warning"):
        level_map = {
            "normal":   logging.INFO,
            "warning":  logging.WARNING,
            "critical": logging.ERROR,
        }
        self._logger.log(level_map.get(severity, logging.WARNING), message)
