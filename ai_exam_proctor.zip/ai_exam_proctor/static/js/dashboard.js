/* dashboard.js — ProctorAI frontend logic */

(function () {
  "use strict";

  // ── DOM refs ──────────────────────────────────────────────────────────────
  const logList        = document.getElementById("log-list");
  const gaugeDot       = document.getElementById("gauge-dot");
  const gaugeLabel     = document.getElementById("gauge-label");
  const statFaces      = document.getElementById("stat-faces");
  const statMobile     = document.getElementById("stat-mobile");
  const statViolations = document.getElementById("stat-violations");
  const statTime       = document.getElementById("stat-time");
  const toast          = document.getElementById("toast");
  const banner         = document.getElementById("violation-banner");
  const clock          = document.getElementById("clock");

  // ── State ─────────────────────────────────────────────────────────────────
  let violationCount = 0;
  let sessionStart   = Date.now();
  let toastTimer     = null;
  const MAX_LOGS     = 50;

  // ── Clock ─────────────────────────────────────────────────────────────────
  function updateClock() {
    const now = new Date();
    clock.textContent = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });

    const elapsed = Math.floor((Date.now() - sessionStart) / 1000);
    const m = String(Math.floor(elapsed / 60)).padStart(2, "0");
    const s = String(elapsed % 60).padStart(2, "0");
    statTime.textContent = `${m}:${s}`;
  }
  setInterval(updateClock, 1000);
  updateClock();

  // ── SSE log stream ────────────────────────────────────────────────────────
  const evtSource = new EventSource("/logs");

  evtSource.onmessage = function (e) {
    const data = JSON.parse(e.data);
    addLogEntry(data);
    updateGauge(data);
    updateStats(data);

    if (data.cheating) {
      violationCount++;
      statViolations.textContent = violationCount;
      showBanner(data.status);
      if (data.severity === "critical") showToast("🚨 " + data.status);
    } else {
      hideBanner();
    }
  };

  evtSource.onerror = function () {
    addLogEntry({ time: "--:--:--", status: "Connection lost – retrying…", severity: "warning", cheating: false });
  };

  // ── Log entry ─────────────────────────────────────────────────────────────
  function addLogEntry(data) {
    const div = document.createElement("div");
    div.className = "log-item " + severityClass(data.severity, data.cheating);

    const t = document.createElement("span");
    t.className   = "log-time";
    t.textContent = data.time;

    const m = document.createElement("span");
    m.className   = "log-msg";
    m.textContent = data.status;

    div.appendChild(t);
    div.appendChild(m);
    logList.prepend(div);

    // Prune old entries
    while (logList.children.length > MAX_LOGS) {
      logList.removeChild(logList.lastChild);
    }
  }

  function severityClass(severity, cheating) {
    if (severity === "critical") return "critical";
    if (cheating || severity === "warning") return "warning";
    return "info";
  }

  // ── Gauge update ──────────────────────────────────────────────────────────
  function updateGauge(data) {
    gaugeDot.className = "gauge-dot";
    if (data.severity === "critical") {
      gaugeDot.classList.add("critical");
      gaugeLabel.textContent = "⚠️ Critical";
    } else if (data.severity === "warning" || data.cheating) {
      gaugeDot.classList.add("warning");
      gaugeLabel.textContent = "⚠️ Warning";
    } else {
      gaugeLabel.textContent = "✅ Normal";
    }
  }

  // ── Sidebar stats ─────────────────────────────────────────────────────────
  function updateStats(data) {
    if (data.face_count !== undefined) statFaces.textContent = data.face_count;
    if (data.mobile     !== undefined) statMobile.textContent = data.mobile ? "Yes ⚠️" : "No";
  }

  // ── Violation banner ──────────────────────────────────────────────────────
  function showBanner(msg) {
    banner.textContent = msg;
    banner.classList.remove("hidden");
  }
  function hideBanner() {
    banner.classList.add("hidden");
  }

  // ── Toast notification ────────────────────────────────────────────────────
  function showToast(msg) {
    clearTimeout(toastTimer);
    toast.textContent = msg;
    toast.classList.remove("hidden");
    toastTimer = setTimeout(() => toast.classList.add("hidden"), 4000);
  }

  // ── Clear logs ────────────────────────────────────────────────────────────
  window.clearLogs = function () {
    logList.innerHTML = "";
    violationCount    = 0;
    statViolations.textContent = "0";
  };

})();
