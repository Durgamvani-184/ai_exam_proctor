"""
Alert Manager — rate-limited, severity-aware alert system.
Prevents alert spam by enforcing a cooldown per alert type.
"""

import time
from collections import deque

# Cooldown in seconds before the same alert fires again
_COOLDOWN = {"normal": 0, "warning": 4, "critical": 2}

_MAX_HISTORY = 200


class AlertManager:
    def __init__(self):
        self._last_alert: dict[str, float] = {}   # message → timestamp
        self._history: deque = deque(maxlen=_MAX_HISTORY)

    def trigger(self, severity: str, message: str) -> bool:
        """
        Fire an alert if cooldown has elapsed.
        Returns True if the alert was actually fired.
        """
        now      = time.time()
        cooldown = _COOLDOWN.get(severity, 3)
        key      = f"{severity}:{message}"

        if now - self._last_alert.get(key, 0) < cooldown:
            return False   # still in cooldown

        self._last_alert[key] = now
        record = {
            "time":     time.strftime("%H:%M:%S"),
            "message":  message,
            "severity": severity,
        }
        self._history.appendleft(record)
        return True

    def get_history(self) -> list:
        return list(self._history)

    def clear(self):
        self._history.clear()
        self._last_alert.clear()
